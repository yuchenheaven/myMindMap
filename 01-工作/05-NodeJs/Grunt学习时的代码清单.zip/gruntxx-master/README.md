gruntxx
=======

Grunt 新手一日学会 配套示例项目。

详情请看文章：<http://yujiangshui.com/grunt-basic-tutorial/>

切换到 grunt 分支有惊喜。
